const path = require("path");
const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const fetch = require('node-fetch');

const postsRoutes = require("./routes/posts");
const userRoutes = require("./routes/user");

const app = express();

app.enable('trust proxy');

mongoose
.connect(
  "mongodb+srv://Viktor:" +
    process.env.MONGO_ATLAS_PW +
    "@cluster0.yivkoun.mongodb.net/test?retryWrites=true&w=majority"
)
  .then(() => {
    console.log("Connected to database!");
  })
  .catch(() => {
    console.log("Connection failed!");
  });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use("/images", express.static(path.join(__dirname, "images")));
// app.use("/images", express.static(__dirname + "/images"));
app.use("/", express.static(path.join(__dirname, "angular")));

 app.use((req, res, next) => {
   res.setHeader("Access-Control-Allow-Origin", "*");
   res.setHeader(
     "Access-Control-Allow-Headers",
     "Origin, X-Requested-With, Content-Type, Accept, Authorization"
   );
   res.setHeader(
     "Access-Control-Allow-Methods",
     "GET, POST, PATCH, PUT, DELETE, OPTIONS"
   );
   next();
 });

app.use("/api/posts", postsRoutes);
app.use("/api/user", userRoutes);
app.use((req, res, next) => {
  res.sendFile(path.join(__dirname, "angular", "index.html"));
});

// The following environment variable is set by app.yaml when running on App
// Engine, but will need to be set manually when running locally. See README.md.
// const {GA_TRACKING_ID} = process.env;

const trackEvent = (category, action, label, value) => {
  const data = {
    // API Version.
    v: '2',
    // Tracking ID / Property ID.
    tid: process.env.GA_TRACKING_ID,
    // Anonymous Client Identifier. Ideally, this should be a UUID that
    // is associated with particular user, device, or browser instance.
    cid: '555',
    // Event hit type.
    t: 'event',
    // Event category.
    ec: category,
    // Event action.
    // ea: action,
    // Event label.
    el: label,
    // Event value.
    ev: value,
  };
  console.log('data',data);
  return fetch('http://www.google-analytics.com/g/collect', action, {
    params: data,
  });
};

// var url = 'https://www.google-analytics.com/debug/collect?v=1&tid=G-G7G7RYJ9BW&cid=555&t=event&ec=current_uah_usd_ratio&ea=set&el=exchange_rate&ev=36'
 
async function gaCollect(){
  let dataForGoogleAnalytics;
  const urlNBU = 'https://bank.gov.ua/NBU_Exchange/exchange_site?&valcode=usd&sort=exchangedate&order=desc&json';
  const today = new Date();
  const yyyy = today.getFullYear();
  let mm = today.getMonth() + 1;
  let dd = today.getDate();
  if (dd < 10) dd = '0' + dd;
  if (mm < 10) mm = '0' + mm;
  const formattedToday = dd + '.' + mm + '.' + yyyy;
  const bodyNBU = { "r030":840,"txt":"Долар США","cc":"USD","exchangedate": `${ formattedToday }`};
  await fetch(urlNBU,{method: 'GET', body: JSON.stringify(bodyNBU)})
    .then((response) => {
      return response.json();
    })
    .then((data) => {
      dataForGoogleAnalytics = data;
      console.log(data);
    });

  //const url = 'https://www.google-analytics.com/g/collect?v=2&tid=G-G7G7RYJ9BW&cid=356465078.1662302855&en=exchange_rate&_ee=1&ep.event_category=current_uah_usd_ratio&ep.event_label=exchange_rate_label&epn.value=37&_et=1'
  //const body = {v: "1", tid: "G-G7G7RYJ9BW", cid: "555", t: "event", ec: "ws", ea: "get", el: "test", ev: `${ dataForGoogleAnalytics.rate || 0 }`}
  //body = { "en":"exchange_rate", "_ee":1,"ep.event_category":"current_uah_usd_ratio","ep.event_label":"exchange_rate_label","epn.value":37,"_et":1}
  body = { "ea":"exchange_rate", "ec":"current_uah_usd_ratio","el":"exchange_rate_label","ev":37}
  // const res = await fetch(url,{method: 'POST', body: JSON.stringify(body)}).then(function (res) {
  const url = 'http://www.google-analytics.com/collect?v=2&tid=G-G7G7RYJ9BW&ea=exchange_rate&ec=current_uah_usd_ratio&el=exchange_rate_label&ev=37'
  const res = await fetch(url, {
    method: 'POST', payload: "v=2&tid=G-G7G7RYJ9BW&ea=exchange_rate&ec=current_uah_usd_ratio&el=exchange_rate_label&ev=37",
  })
    .then((response) => {
      // console.log(response);
      //return response.json();
    })
    .then((data) => {
      // console.log(data);
    });
    const urlTest = 'http://www.google-analytics.com/g/collect?v=1&tid=G-G7G7RYJ9BW&cid=555&t=pageview&dp=%2Fhome'
  
    await fetch(urlTest, {
      method: 'GET',
    })
    //var resTest = await fetch(url,{method:'POST'});
 // var data = await resTest.json();
  //console.log(data.hitParsingResult[0])
  // await fetch(url,{method: 'POST', body: JSON.stringify(body)}).then(function (res) {

}

gaCollect();



const apiTimeout = 10 * 1000;
console.log('apiTimeout',apiTimeout);

app.get('/', async (req, res, next) => {
  console.log('req',req);
  // Event value must be numeric.
  req.setTimeout(apiTimeout, async () => {
    try {
      await trackEvent(
        'current_uah_usd_ratio',
        'exchange_rate',
        'exchange_rate',
        '40'
      );
      res.status(200).send('Event tracked.').end();
      console.log('req',req);
      console.log('res',res);
    } catch (error) {
      console.log('error',error);
      // This sample treats an event tracking error as a fatal error. Depending
      // on your application's needs, failing to track an event may not be
      // considered an error.
      next(error);
    }
  });
});

module.exports = app;
